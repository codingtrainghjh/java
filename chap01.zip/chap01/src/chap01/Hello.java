package chap01;

public class Hello {

	public static void main(String[] args) {
		//영어로 인사
		greetEn()greetEn()greetEn()greetEn()
	
		//한글로 인사
		greet();
		
		//자기이름
		info();
	}
	
	public static void greetEn() {
		System.out.println("Hello");
	}
}

	
	
	
	
pu info