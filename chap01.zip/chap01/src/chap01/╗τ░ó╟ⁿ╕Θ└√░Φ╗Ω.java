package chap01;
import java.util.Scanner;
public class 사각형면적계산 {
	public static void main(String[] args) {
		
		int w, h, area;
		
	Scanner scan = new Scanner(System.in);
	System.out.print("가로입력:");
	w = Integer.parseInt( scan.nextLine() );          //가로값을 키보드로 입력받아서 w 변수에 저장
	
	System.out.print("세로입력:");
	h = Integer.parseInt( scan.nextLine() );          //세로 입력
	
	System.out.print("면적계산:");
	area = w*h ;    //가로와 세로를 곱해서 면적 계산한 뒤 area 변수에 저장
	System.out.println("면적=" + area); //면적 출력
   }
}